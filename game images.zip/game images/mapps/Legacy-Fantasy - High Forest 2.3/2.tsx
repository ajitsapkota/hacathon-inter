<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="2" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="Assets/Tiles.png" width="400" height="400"/>
</tileset>
