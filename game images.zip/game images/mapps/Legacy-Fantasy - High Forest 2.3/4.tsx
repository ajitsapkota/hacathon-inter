<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="4" tilewidth="32" tileheight="32" tilecount="224" columns="28">
 <image source="Trees/Background.png" width="896" height="256"/>
</tileset>
