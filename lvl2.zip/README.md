# 2D Platformer Game - Find the Doctor

A Pygame-based 2D platformer game using TMX maps for terrain and objects.

## Features

- **Player Movement**: Control the player with arrow keys or WASD
- **TMX Map Integration**: Uses the provided TMX map for terrain and collision detection
- **Coin Collection**: Collect 10 coins scattered around the map
- **Trap System**: Avoid traps that will instantly kill the player
- **Quest System**: Find and save the doctor NPC
- **Lives System**: Start with 3 lives, lose one when touching traps
- **UI Elements**: Display lives, coin count, and quest status
- **Game States**: Game over and victory screens with restart functionality

## Installation

1. Install Python 3.7 or higher
2. Install required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## How to Run

1. Make sure you're in the project directory
2. Run the main game file:
   ```bash
   python main.py
   ```

## Controls

- **Arrow Keys** or **WASD**: Move left/right
- **Space** or **Up/W**: Jump
- **R**: Restart game (when game over or victory)
- **ESC**: Quit game

## Game Objective

1. Talk to the parent NPC at the start to receive your quest
2. Collect 10 coins scattered around the map
3. Once you have 10 coins, the doctor will appear
4. Find and touch the doctor to complete the quest and win the game
5. Avoid traps - they will instantly kill you and cost you a life

## Game Files

- `main.py`: Main game loop and initialization
- `player.py`: Player character with movement and collision detection
- `items.py`: Coin and trap objects
- `npc.py`: Parent and doctor NPCs with quest interactions
- `ui.py`: User interface elements and screens
- `requirements.txt`: Python dependencies
- `maps/usethis.tmx`: The TMX map file used for terrain

## Map Layers

The TMX map contains the following layers:
- **Tile Layer 1**: Main terrain tiles
- **background**: Background decoration layer
- **ground**: Collision layer for solid ground
- **trap**: Trap layer for deadly hazards
- **climb**: Climbing surfaces (not used in current implementation)

## Technical Details

- Built with Pygame 2.5.2 and pytmx 3.32
- 60 FPS game loop
- Tile-based collision detection
- Sprite-based animation system
- Modular code structure for easy extension

## Troubleshooting

If you encounter issues:
1. Make sure all dependencies are installed: `pip install -r requirements.txt`
2. Ensure the `maps/usethis.tmx` file exists in the correct location
3. Check that you have Python 3.7 or higher installed
4. Make sure you're running the game from the correct directory

Enjoy the game!
