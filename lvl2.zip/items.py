"""
Items class for the 2D platformer game.
Contains Coin and Trap classes for collectibles and hazards.
"""

import pygame
import math

class Coin:
    def __init__(self, x, y):
        """Initialize a coin at the specified position."""
        self.x = x
        self.y = y
        self.radius = 8  # Normal radius for full-size tiles
        self.rect = pygame.Rect(x - self.radius, y - self.radius, 
                               self.radius * 2, self.radius * 2)
        
        # Animation properties
        self.animation_timer = 0
        self.bob_offset = 0
        self.bob_speed = 0.1
        self.bob_amplitude = 3
        
        # Collection properties
        self.collected = False
        self.collection_timer = 0
        self.collection_duration = 30  # frames
    
    def update(self):
        """Update coin animation and collection state."""
        if not self.collected:
            # Bobbing animation
            self.animation_timer += 1
            self.bob_offset = math.sin(self.animation_timer * self.bob_speed) * self.bob_amplitude
            self.rect.y = self.y - self.radius + self.bob_offset
        else:
            # Collection animation
            self.collection_timer += 1
            if self.collection_timer >= self.collection_duration:
                return True  # Signal to remove this coin
        return False
    
    def collect(self):
        """Mark the coin as collected."""
        self.collected = True
        self.collection_timer = 0
    
    def draw(self, screen, camera_x, camera_y):
        """Draw the coin on the screen."""
        if not self.collected:
            # Calculate screen position with camera offset
            screen_x = self.rect.x - camera_x
            screen_y = self.rect.y - camera_y
            
            # Draw coin with gradient effect
            center_x = screen_x + self.rect.width // 2
            center_y = screen_y + self.rect.height // 2
            
            # Outer ring
            pygame.draw.circle(screen, (255, 215, 0), (center_x, center_y), self.radius)
            pygame.draw.circle(screen, (255, 255, 0), (center_x, center_y), self.radius - 2)
            
            # Inner circle
            pygame.draw.circle(screen, (255, 215, 0), (center_x, center_y), self.radius - 4)
            
            # Highlight
            pygame.draw.circle(screen, (255, 255, 255), 
                             (center_x - 2, center_y - 2), 2)
        else:
            # Collection animation - scale down and fade
            scale = 1.0 - (self.collection_timer / self.collection_duration)
            if scale > 0:
                scaled_radius = int(self.radius * scale)
                if scaled_radius > 0:
                    screen_x = self.rect.x - camera_x
                    screen_y = self.rect.y - camera_y
                    center_x = screen_x + self.rect.width // 2
                    center_y = screen_y + self.rect.height // 2
                    pygame.draw.circle(screen, (255, 215, 0), 
                                     (center_x, center_y), scaled_radius)

class Trap:
    def __init__(self, x, y):
        """Initialize a trap at the specified position."""
        self.x = x
        self.y = y
        self.width = 32  # Normal trap size
        self.height = 32
        self.rect = pygame.Rect(x, y, self.width, self.height)
        
        # Animation properties
        self.animation_timer = 0
        self.pulse_speed = 0.2
        self.pulse_amplitude = 0.3
        
        # Visual properties
        self.base_color = (200, 50, 50)  # Dark red
        self.pulse_color = (255, 100, 100)  # Light red
    
    def update(self):
        """Update trap animation."""
        self.animation_timer += 1
    
    def draw(self, screen, camera_x, camera_y):
        """Draw the trap on the screen."""
        # Calculate screen position with camera offset
        screen_x = self.rect.x - camera_x
        screen_y = self.rect.y - camera_y
        
        # Pulsing effect
        pulse = math.sin(self.animation_timer * self.pulse_speed) * self.pulse_amplitude
        current_scale = 1.0 + pulse
        
        # Draw trap with pulsing effect
        scaled_width = int(self.width * current_scale)
        scaled_height = int(self.height * current_scale)
        
        # Center the scaled trap
        offset_x = (self.width - scaled_width) // 2
        offset_y = (self.height - scaled_height) // 2
        
        trap_rect = pygame.Rect(screen_x + offset_x, screen_y + offset_y, 
                               scaled_width, scaled_height)
        
        # Draw trap body
        pygame.draw.rect(screen, self.base_color, trap_rect)
        pygame.draw.rect(screen, self.pulse_color, trap_rect, 2)
        
        # Draw spikes
        spike_height = scaled_height // 3
        for i in range(3):
            spike_x = trap_rect.x + (i + 1) * (scaled_width // 4)
            spike_points = [
                (spike_x, trap_rect.y + scaled_height),
                (spike_x - 3, trap_rect.y + scaled_height - spike_height),
                (spike_x + 3, trap_rect.y + scaled_height - spike_height)
            ]
            pygame.draw.polygon(screen, (100, 0, 0), spike_points)
        
        # Draw warning symbol
        center_x = trap_rect.centerx
        center_y = trap_rect.centery
        warning_size = min(scaled_width, scaled_height) // 4
        
        # Exclamation mark
        pygame.draw.rect(screen, (255, 255, 255), 
                        (center_x - 2, center_y - warning_size, 4, warning_size))
        pygame.draw.circle(screen, (255, 255, 255), 
                         (center_x, center_y + warning_size // 2), 3)
