"""
Main game file for the 2D platformer game using TMX maps.
This file contains the main game loop, initialization, and state management.
"""

import pygame
import pytmx
import sys
import os
from player import Player
from items import Coin, Trap
from npc import ParentNPC, DoctorNPC
from ui import UI

class Game:
    def __init__(self):
        """Initialize the game with Pygame and load the TMX map."""
        pygame.init()
        
        # Game constants
        self.SCREEN_WIDTH = 1024
        self.SCREEN_HEIGHT = 768
        self.TILE_SIZE = 32
        
        # Initialize display
        self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        pygame.display.set_caption("2D Platformer - Find the Doctor")
        
        # Game clock
        self.clock = pygame.time.Clock()
        self.FPS = 60
        
        # Game state
        self.running = True
        self.game_state = "playing"  # "playing", "game_over", "victory"
        
        # Scaling settings
        self.map_scale = 1.0  # Scale up map tiles (1.0 = original size - 100% scale up)
        self.player_scale = 1.0  # Normal player size
        
        # Load TMX map
        self.load_map()
        
        # Initialize game objects
        self.player = None
        self.coins = []
        self.traps = []
        self.parent_npc = None
        self.doctor_npc = None
        
        # Game stats
        self.lives = 3
        self.coins_collected = 0
        self.coins_needed = 10
        self.doctor_spawned = False
        
        # Initialize UI
        self.ui = UI(self.screen)
        
        # Initialize camera
        self.camera_x = 0
        self.camera_y = 0
        
        # Initialize game objects
        self.initialize_objects()
        
    def load_map(self):
        """Load the TMX map file and extract tile data."""
        try:
            # Load TMX data without pygame integration for now
            import xml.etree.ElementTree as ET
            self.tmx_data = ET.parse("maps/yoramro.tmx")
            self.root = self.tmx_data.getroot()
            
            # Get map properties
            self.map_width = int(self.root.get('width'))
            self.map_height = int(self.root.get('height'))
            self.tile_width = int(self.root.get('tilewidth'))
            self.tile_height = int(self.root.get('tileheight'))
            
            print("TMX map loaded successfully!")
            print(f"Map size: {self.map_width}x{self.map_height}")
            print(f"Tile size: {self.tile_width}x{self.tile_height}")
            
            # Load tilesets
            self.tilesets = {}
            for tileset in self.root.findall('tileset'):
                first_gid = int(tileset.get('firstgid'))
                source = tileset.get('source')
                if source:
                    # Load the tileset file
                    tileset_path = f"maps/{source}"
                    tileset_data = ET.parse(tileset_path)
                    tileset_root = tileset_data.getroot()
                    
                    # Get tileset properties
                    tile_width = int(tileset_root.get('tilewidth'))
                    tile_height = int(tileset_root.get('tileheight'))
                    columns = int(tileset_root.get('columns'))
                    
                    # Get image source
                    image_element = tileset_root.find('image')
                    if image_element is not None:
                        image_source = image_element.get('source')
                        image_width = int(image_element.get('width'))
                        image_height = int(image_element.get('height'))
                        
                        # Load the tileset image
                        tileset_image = pygame.image.load(f"maps/{image_source}")
                        tileset_image = tileset_image.convert_alpha()
                        
                        self.tilesets[first_gid] = {
                            'image': tileset_image,
                            'tile_width': tile_width,
                            'tile_height': tile_height,
                            'columns': columns,
                            'image_width': image_width,
                            'image_height': image_height
                        }
                        print(f"Loaded tileset {first_gid}: {source}")
            
            # Load layer data
            self.layers = {}
            for layer in self.root.findall('layer'):
                layer_name = layer.get('name')
                data_element = layer.find('data')
                if data_element is not None:
                    # Parse CSV data
                    csv_data = data_element.text.strip().replace('\n', '').split(',')
                    # Convert to 2D array
                    layer_data = []
                    for y in range(self.map_height):
                        row = []
                        for x in range(self.map_width):
                            index = y * self.map_width + x
                            if index < len(csv_data):
                                row.append(int(csv_data[index]))
                            else:
                                row.append(0)
                        layer_data.append(row)
                    self.layers[layer_name] = layer_data
                    print(f"Loaded layer '{layer_name}' with {len(layer_data)} rows")
            
        except Exception as e:
            print(f"Error loading TMX map: {e}")
            sys.exit(1)
    
    def initialize_objects(self):
        """Initialize player, coins, traps, and NPCs based on the map."""
        # Find a good spawn position with ground tiles
        spawn_x, spawn_y = self.find_ground_spawn_position()
        self.player = Player(spawn_x, spawn_y, self)
        print(f"Player spawned at: {self.player.rect.x}, {self.player.rect.y}")
        
        # Check what tiles are around the player
        player_tile_x = self.player.rect.x // self.tile_width
        player_tile_y = self.player.rect.y // self.tile_height
        print(f"Player tile position: ({player_tile_x}, {player_tile_y})")
        
        # Check ground tiles around player
        if "ground" in self.layers:
            ground_layer = self.layers["ground"]
            print("Ground tiles around player:")
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    check_x = player_tile_x + dx
                    check_y = player_tile_y + dy
                    if 0 <= check_x < self.map_width and 0 <= check_y < self.map_height:
                        tile_gid = ground_layer[check_y][check_x]
                        print(f"  Ground at ({check_x}, {check_y}): GID {tile_gid}")
        
        # Check background tiles around player
        if "background" in self.layers:
            background_layer = self.layers["background"]
            print("Background tiles around player:")
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    check_x = player_tile_x + dx
                    check_y = player_tile_y + dy
                    if 0 <= check_x < self.map_width and 0 <= check_y < self.map_height:
                        tile_gid = background_layer[check_y][check_x]
                        print(f"  Background at ({check_x}, {check_y}): GID {tile_gid}")
    
    def get_player_spawn_from_tmx(self):
        """Get player spawn position from TMX object layer."""
        # Check if there's a player object layer in the TMX
        if hasattr(self, 'tmx_data') and hasattr(self.tmx_data, 'getroot'):
            root = self.tmx_data.getroot()
            
            # Look for object groups
            for objectgroup in root.findall('objectgroup'):
                group_name = objectgroup.get('name', '').lower()
                if 'player' in group_name:
                    print(f"Found player object group: {objectgroup.get('name')}")
                    
                    # Get the first player object
                    for obj in objectgroup.findall('object'):
                        x = float(obj.get('x', 0))
                        y = float(obj.get('y', 0))
                        print(f"Player spawn from TMX: ({x}, {y})")
                        return x, y
        
        # Also check for any object with name containing "player"
        for objectgroup in root.findall('objectgroup'):
            for obj in objectgroup.findall('object'):
                obj_name = obj.get('name', '').lower()
                if 'player' in obj_name:
                    x = float(obj.get('x', 0))
                    y = float(obj.get('y', 0))
                    print(f"Player spawn from TMX object '{obj_name}': ({x}, {y})")
                    return x, y
        
        print("No player object found in TMX, using fallback spawn position")
        # Fallback: look for ground tiles and place player above them
        return self.find_ground_spawn_position()
    
    def find_ground_spawn_position(self):
        """Find a good spawn position with ground tiles."""
        if "ground" not in self.layers:
            return 100, 500  # Fallback position
        
        ground_layer = self.layers["ground"]
        
        # Look for ground tiles starting from the middle-bottom of the map
        # This should give us a better area with more interesting terrain
        start_y = int(self.map_height * 0.8)  # Start from 80% down the map
        end_y = self.map_height - 1
        
        for y in range(end_y, start_y - 1, -1):  # Start from bottom, go up
            for x in range(self.map_width // 4, self.map_width * 3 // 4):  # Middle section of map
                tile_gid = ground_layer[y][x]
                if tile_gid != 0:  # Found a ground tile
                    # Convert to pixel coordinates and place player above ground
                    pixel_x = x * self.tile_width
                    pixel_y = (y - 2) * self.tile_height  # Place 2 tiles above ground
                    print(f"Found ground tile at ({x}, {y}) with GID {tile_gid}")
                    print(f"Spawning player at pixel coordinates: ({pixel_x}, {pixel_y})")
                    return pixel_x, pixel_y
        
        # If no ground found in middle section, try the original method
        for y in range(self.map_height - 1, -1, -1):  # Start from bottom
            for x in range(self.map_width):
                tile_gid = ground_layer[y][x]
                if tile_gid != 0:  # Found a ground tile
                    # Convert to pixel coordinates and place player above ground
                    pixel_x = x * self.tile_width
                    pixel_y = (y - 2) * self.tile_height  # Place 2 tiles above ground
                    print(f"Found ground tile at ({x}, {y}) with GID {tile_gid}")
                    print(f"Spawning player at pixel coordinates: ({pixel_x}, {pixel_y})")
                    return pixel_x, pixel_y
        
        # If no ground found, return default position
        print("No ground tiles found, using default spawn position")
        return 100, 500
    
    def initialize_objects(self):
        """Initialize player, coins, traps, and NPCs based on the map."""
        # Get player spawn position from TMX or find ground
        spawn_x, spawn_y = self.get_player_spawn_from_tmx()
        # Scale the spawn position to match the scaled map
        spawn_x = int(spawn_x * self.map_scale)
        spawn_y = int(spawn_y * self.map_scale)
        self.player = Player(spawn_x, spawn_y, self, scale=self.player_scale)
        print(f"Player spawned at: {self.player.rect.x}, {self.player.rect.y}")
        
        # Initialize camera to start at player position
        self.update_camera()
        print(f"Camera initialized at player position: ({self.camera_x}, {self.camera_y})")
        
        # Check what tiles are around the player
        player_tile_x = self.player.rect.x // self.tile_width
        player_tile_y = self.player.rect.y // self.tile_height
        print(f"Player tile position: ({player_tile_x}, {player_tile_y})")
        
        # Check ground tiles around player
        if "ground" in self.layers:
            ground_layer = self.layers["ground"]
            print("Ground tiles around player:")
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    check_x = player_tile_x + dx
                    check_y = player_tile_y + dy
                    if 0 <= check_x < self.map_width and 0 <= check_y < self.map_height:
                        tile_gid = ground_layer[check_y][check_x]
                        print(f"  Ground at ({check_x}, {check_y}): GID {tile_gid}")
        
        # Check background tiles around player
        if "background" in self.layers:
            background_layer = self.layers["background"]
            print("Background tiles around player:")
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    check_x = player_tile_x + dx
                    check_y = player_tile_y + dy
                    if 0 <= check_x < self.map_width and 0 <= check_y < self.map_height:
                        tile_gid = background_layer[check_y][check_x]
                        print(f"  Background at ({check_x}, {check_y}): GID {tile_gid}")
        
        # Create coins scattered around the map
        self.create_coins()
        
        # Create traps based on the trap layer
        self.create_traps()
        
        # Create NPCs from TMX object layer
        self.create_npcs_from_tmx()
        
        # Fallback: Create parent NPC if none found in TMX
        if not self.parent_npc:
            self.parent_npc = ParentNPC(50, 450, self.map_scale)
            print("Created fallback parent NPC")
    
    def update_camera(self):
        """Update camera to follow player and clamp to map boundaries."""
        # Map dimensions in pixels (scaled)
        map_width = self.map_width * self.tile_width * self.map_scale
        map_height = self.map_height * self.tile_height * self.map_scale
        
        # Center camera on player
        target_camera_x = self.player.rect.centerx - self.screen.get_width() // 2
        target_camera_y = self.player.rect.centery - self.screen.get_height() // 2
        
        # Clamp camera to map boundaries
        max_camera_x = max(0, map_width - self.screen.get_width())
        max_camera_y = max(0, map_height - self.screen.get_height())
        
        self.camera_x = max(0, min(target_camera_x, max_camera_x))
        self.camera_y = max(0, min(target_camera_y, max_camera_y))
        
        print(f"Camera position: ({self.camera_x}, {self.camera_y})")
        
    def create_coins(self):
        """Create coin objects from TMX coin object layer."""
        # Check if there's a coin object layer in the TMX
        if hasattr(self, 'tmx_data') and hasattr(self.tmx_data, 'getroot'):
            root = self.tmx_data.getroot()
            
            # Look for coin object groups
            for objectgroup in root.findall('objectgroup'):
                group_name = objectgroup.get('name', '').lower()
                if 'coin' in group_name:
                    print(f"Found coin object group: {objectgroup.get('name')}")
                    
                    # Get all coin objects (max 10)
                    for obj in objectgroup.findall('object'):
                        if len(self.coins) >= 10:  # Max 10 coins
                            break
                        x = float(obj.get('x', 0))
                        y = float(obj.get('y', 0))
                        # Scale the position to match the scaled map
                        scaled_x = int(x * self.map_scale)
                        scaled_y = int(y * self.map_scale)
                        coin = Coin(scaled_x, scaled_y)
                        self.coins.append(coin)
                        print(f"Created coin at: ({scaled_x}, {scaled_y})")
            
            # Also check for any object with name containing "coin"
            for objectgroup in root.findall('objectgroup'):
                for obj in objectgroup.findall('object'):
                    if len(self.coins) >= 10:  # Max 10 coins
                        break
                    obj_name = obj.get('name', '').lower()
                    if 'coin' in obj_name:
                        x = float(obj.get('x', 0))
                        y = float(obj.get('y', 0))
                        # Scale the position to match the scaled map
                        scaled_x = int(x * self.map_scale)
                        scaled_y = int(y * self.map_scale)
                        coin = Coin(scaled_x, scaled_y)
                        self.coins.append(coin)
                        print(f"Created coin from object '{obj_name}' at: ({scaled_x}, {scaled_y})")
        
        # Fallback: if no coins found in TMX, use default positions (max 10)
        if not self.coins:
            print("No coin objects found in TMX, using fallback positions")
            coin_positions = [
                (200, 500), (300, 400), (400, 350), (500, 300),
                (600, 450), (700, 380), (800, 320), (900, 280),
                (1000, 400), (1100, 350)
            ]
            
            for x, y in coin_positions:
                self.coins.append(Coin(x, y))
        
        print(f"Total coins created: {len(self.coins)}")
    
    def create_npcs_from_tmx(self):
        """Create NPCs from TMX object layer."""
        # Check if there's an NPC object layer in the TMX
        if hasattr(self, 'tmx_data') and hasattr(self.tmx_data, 'getroot'):
            root = self.tmx_data.getroot()
            
            # Look for NPC object groups
            for objectgroup in root.findall('objectgroup'):
                group_name = objectgroup.get('name', '').lower()
                if 'npc' in group_name or 'parent' in group_name or 'doctor' in group_name:
                    print(f"Found NPC object group: {objectgroup.get('name')}")
                    
                    # Get all NPC objects
                    for obj in objectgroup.findall('object'):
                        x = float(obj.get('x', 0))
                        y = float(obj.get('y', 0))
                        obj_name = obj.get('name', '').lower()
                        
                        # Scale the position to match the scaled map
                        scaled_x = int(x * self.map_scale)
                        scaled_y = int(y * self.map_scale)
                        
                        # Create appropriate NPC based on name
                        if 'parent' in obj_name or 'parent' in group_name:
                            self.parent_npc = ParentNPC(scaled_x, scaled_y, self.map_scale)
                            print(f"Created parent NPC at: ({scaled_x}, {scaled_y})")
                        elif 'doctor' in obj_name or 'doctor' in group_name:
                            self.doctor_npc = DoctorNPC(scaled_x, scaled_y, self.map_scale)
                            self.doctor_spawned = True
                            print(f"Created doctor NPC at: ({scaled_x}, {scaled_y})")
                        else:
                            # Default to parent NPC
                            self.parent_npc = ParentNPC(scaled_x, scaled_y, self.map_scale)
                            print(f"Created default NPC at: ({scaled_x}, {scaled_y})")
            
            # Also check for any object with name containing NPC types
            for objectgroup in root.findall('objectgroup'):
                for obj in objectgroup.findall('object'):
                    obj_name = obj.get('name', '').lower()
                    if 'parent' in obj_name or 'doctor' in obj_name:
                        x = float(obj.get('x', 0))
                        y = float(obj.get('y', 0))
                        
                        # Scale the position to match the scaled map
                        scaled_x = int(x * self.map_scale)
                        scaled_y = int(y * self.map_scale)
                        
                        # Create appropriate NPC based on name
                        if 'parent' in obj_name:
                            self.parent_npc = ParentNPC(scaled_x, scaled_y, self.map_scale)
                            print(f"Created parent NPC from object '{obj_name}' at: ({scaled_x}, {scaled_y})")
                        elif 'doctor' in obj_name:
                            self.doctor_npc = DoctorNPC(scaled_x, scaled_y, self.map_scale)
                            self.doctor_spawned = True
                            print(f"Created doctor NPC from object '{obj_name}' at: ({scaled_x}, {scaled_y})")
    
    def create_traps(self):
        """Create trap objects based on the trap layer in the TMX map."""
        if "trap" in self.layers:
            trap_layer = self.layers["trap"]
            for y in range(self.map_height):
                for x in range(self.map_width):
                    tile_gid = trap_layer[y][x]
                    if tile_gid != 0:  # If there's a trap tile
                        trap_x = x * self.tile_width
                        trap_y = y * self.tile_height
                        self.traps.append(Trap(trap_x, trap_y))
    
    def handle_events(self):
        """Handle pygame events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_r and self.game_state != "playing":
                    self.restart_game()
    
    def update(self, dt):
        """Update game logic."""
        if self.game_state != "playing":
            return
            
        # Update player
        keys = pygame.key.get_pressed()
        self.player.update(keys, dt)
        
        # Update camera to follow player
        self.update_camera()
        
        # Check player collision with ground
        self.check_player_ground_collision()
        
        # Check collisions with traps
        self.check_trap_collisions()
        
        # Check coin collections
        self.check_coin_collisions()
        
        # Check if doctor should spawn
        if not self.doctor_spawned and self.coins_collected >= self.coins_needed:
            self.spawn_doctor()
        
        # Check victory condition
        if self.doctor_npc and self.player.rect.colliderect(self.doctor_npc.rect):
            self.game_state = "victory"
    
    def check_player_ground_collision(self):
        """Check if player collides with solid ground tiles."""
        if "ground" not in self.layers:
            return
            
        ground_layer = self.layers["ground"]
        
        # Check collision with tiles (accounting for scaling)
        scaled_tile_width = self.tile_width * self.map_scale
        scaled_tile_height = self.tile_height * self.map_scale
        left_tile = int(self.player.rect.left // scaled_tile_width)
        right_tile = int(self.player.rect.right // scaled_tile_width)
        top_tile = int(self.player.rect.top // scaled_tile_height)
        bottom_tile = int(self.player.rect.bottom // scaled_tile_height)
        
        # Make sure we're within map bounds
        if (left_tile < 0 or right_tile >= self.map_width or 
            top_tile < 0 or bottom_tile >= self.map_height):
            return
        
        # Check each tile the player overlaps
        for x in range(left_tile, right_tile + 1):
            for y in range(top_tile, bottom_tile + 1):
                if x < self.map_width and y < self.map_height:
                    tile_gid = ground_layer[y][x]
                    if tile_gid != 0:  # If there's a solid tile
                        # Handle collision (using scaled coordinates)
                        if self.player.velocity_y > 0:  # Falling
                            self.player.rect.y = y * scaled_tile_height - self.player.rect.height
                            self.player.on_ground = True
                            self.player.velocity_y = 0
                        elif self.player.velocity_y < 0:  # Jumping
                            self.player.rect.y = (y + 1) * scaled_tile_height
                            self.player.velocity_y = 0
                        elif self.player.velocity_x > 0:  # Moving right
                            self.player.rect.x = x * scaled_tile_width - self.player.rect.width
                        elif self.player.velocity_x < 0:  # Moving left
                            self.player.rect.x = (x + 1) * scaled_tile_width
                        return
    
    def check_trap_collisions(self):
        """Check if player collides with any trap."""
        for trap in self.traps:
            if self.player.rect.colliderect(trap.rect):
                self.player_die()
                break
    
    def check_coin_collisions(self):
        """Check if player collects any coins."""
        coins_to_remove = []
        for coin in self.coins:
            if self.player.rect.colliderect(coin.rect):
                coins_to_remove.append(coin)
                self.coins_collected += 1
                print(f"Coin collected! Total: {self.coins_collected}/{self.coins_needed}")
        
        # Remove collected coins
        for coin in coins_to_remove:
            self.coins.remove(coin)
    
    def spawn_doctor(self):
        """Spawn the doctor NPC when enough coins are collected."""
        if not self.doctor_spawned:
            self.doctor_npc = DoctorNPC(1500, 300)
            self.doctor_spawned = True
            print("Doctor has appeared! Find him to complete your quest!")
    
    def player_die(self):
        """Handle player death."""
        self.lives -= 1
        if self.lives <= 0:
            self.game_state = "game_over"
        else:
            # Reset player position
            self.player.rect.x = 100
            self.player.rect.y = 500
            print(f"Player died! Lives remaining: {self.lives}")
    
    def restart_game(self):
        """Restart the game to initial state."""
        self.game_state = "playing"
        self.lives = 3
        self.coins_collected = 0
        self.doctor_spawned = False
        self.doctor_npc = None
        
        # Reset player position
        self.player.rect.x = 100
        self.player.rect.y = 500
        
        # Reset coins
        self.coins.clear()
        self.create_coins()
    
    def draw(self):
        """Draw everything to the screen."""
        # Clear screen
        self.screen.fill((135, 206, 235))  # Sky blue background
        
        # Draw map layers
        self.draw_map()
        
        # Draw game objects with camera offset
        for coin in self.coins:
            coin.draw(self.screen, self.camera_x, self.camera_y)
        
        for trap in self.traps:
            trap.draw(self.screen, self.camera_x, self.camera_y)
        
        if self.parent_npc:
            self.parent_npc.draw(self.screen, self.camera_x, self.camera_y)
        
        if self.doctor_npc:
            self.doctor_npc.draw(self.screen, self.camera_x, self.camera_y)
        
        # Draw player
        self.player.draw(self.screen, self.camera_x, self.camera_y)
        
        # Draw UI
        self.ui.draw(self.lives, self.coins_collected, self.coins_needed, self.game_state)
        
        # Update display
        pygame.display.flip()
    
    def draw_map(self):
        """Draw the TMX map layers."""
        # Draw background layer
        if "background" in self.layers:
            self.draw_layer("background")
        
        # Draw ground layer
        if "ground" in self.layers:
            self.draw_layer("ground")
    
    def draw_layer(self, layer_name):
        """Draw a specific layer using the loaded tilesets."""
        layer_data = self.layers[layer_name]
        tiles_rendered = 0
        
        # Calculate visible tile range for culling (accounting for scaling)
        scaled_tile_width = self.tile_width * self.map_scale
        scaled_tile_height = self.tile_height * self.map_scale
        start_x = max(0, int(self.camera_x // scaled_tile_width))
        end_x = min(self.map_width, int((self.camera_x + self.screen.get_width()) // scaled_tile_width) + 1)
        start_y = max(0, int(self.camera_y // scaled_tile_height))
        end_y = min(self.map_height, int((self.camera_y + self.screen.get_height()) // scaled_tile_height) + 1)
        
        for y in range(start_y, end_y):
            for x in range(start_x, end_x):
                tile_gid = layer_data[y][x]
                if tile_gid != 0:
                    # Find which tileset this tile belongs to
                    tileset_gid = None
                    for gid in sorted(self.tilesets.keys(), reverse=True):
                        if tile_gid >= gid:
                            tileset_gid = gid
                            break
                    
                    if tileset_gid is not None:
                        tileset = self.tilesets[tileset_gid]
                        local_tile_id = tile_gid - tileset_gid
                        
                        # Calculate tile position in the tileset
                        tile_x = (local_tile_id % tileset['columns']) * tileset['tile_width']
                        tile_y = (local_tile_id // tileset['columns']) * tileset['tile_height']
                        
                        # Create a surface for the tile
                        tile_surface = pygame.Surface((tileset['tile_width'], tileset['tile_height']), pygame.SRCALPHA)
                        tile_surface.blit(tileset['image'], (0, 0), (tile_x, tile_y, tileset['tile_width'], tileset['tile_height']))
                        
                        # Scale the tile surface
                        scaled_width = int(tileset['tile_width'] * self.map_scale)
                        scaled_height = int(tileset['tile_height'] * self.map_scale)
                        if scaled_width > 0 and scaled_height > 0:
                            scaled_tile = pygame.transform.scale(tile_surface, (scaled_width, scaled_height))
                            
                            # Draw the scaled tile with camera offset
                            screen_x = int(x * self.tile_width * self.map_scale - self.camera_x)
                            screen_y = int(y * self.tile_height * self.map_scale - self.camera_y)
                            self.screen.blit(scaled_tile, (screen_x, screen_y))
                        tiles_rendered += 1
        
        # Debug output
        if tiles_rendered > 0:
            print(f"Rendered {tiles_rendered} tiles from layer '{layer_name}'")
        else:
            print(f"No tiles rendered from layer '{layer_name}' - checking first few tiles:")
            for y in range(min(5, self.map_height)):
                for x in range(min(10, self.map_width)):
                    tile_gid = layer_data[y][x]
                    if tile_gid != 0:
                        print(f"  Tile at ({x}, {y}): GID {tile_gid}")
    
    def run(self):
        """Main game loop."""
        dt = 0.016  # Initialize dt with a default value
        
        while self.running:
            self.handle_events()
            self.update(dt)
            self.draw()
            dt = self.clock.tick(self.FPS) / 1000.0
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
