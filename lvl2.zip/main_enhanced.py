import pygame
import sys
import time
import xml.etree.ElementTree as ET
import os
import math
from player import Player
from npc import ParentNPC, DoctorNPC
from items import Coin, Trap
from ui import UI

class Game:
    def __init__(self):
        """Initialize the game with enhanced features"""
        pygame.init()
        
        # Performance detection
        self.detect_performance_settings()
        
        # Setup resolution
        self.setup_resolution()
        
        # Initialize game objects
        self.clock = pygame.time.Clock()
        self.paused = False
        
        # Scale factors (updated by setup_resolution)
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.scale_factor = 1.0
        
        # UI settings
        self.font_size = int(24 * self.scale_factor)
        self.ui_padding = int(20 * self.scale_factor)
        
        # Performance monitoring
        self.frame_times = []
        self.last_frame_time = time.time()
        self.fps = 60.0  # Initialize FPS
        
        # Tile cache for performance
        self.tile_cache = {}
        
        # Load game assets
        self.load_game_assets()
        
        # Load sound effects
        self.load_sound_effects()
        
        # Initialize game state
        self.reset_game()

    def detect_performance_settings(self):
        """Detect system performance capabilities"""
        try:
            # Get screen info
            info = pygame.display.Info()
            screen_width = info.current_w
            screen_height = info.current_h
            
            if screen_width >= 1920 and screen_height >= 1080:
                self.performance_level = "high"
            elif screen_width >= 1366 and screen_height >= 768:
                self.performance_level = "medium"
            else:
                self.performance_level = "low"
        except:
            self.performance_level = "low"

    def setup_resolution(self):
        """Setup game resolution to match map size"""
        # Map size: 1920x1080 tiles, 32x32 pixels each
        self.screen_width = 1920  # Full map width
        self.screen_height = 1080  # Full map height
        
        # Create screen with map dimensions
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Mossy Forest Adventure")
        
        # No scaling needed - 1:1 pixel mapping
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.scale_factor = 1.0
        
        print(f"Window size: {self.screen_width}x{self.screen_height}")
        print(f"Map size: {self.screen_width}x{self.screen_height}")
        print(f"Scale factors: X={self.scale_x:.2f}, Y={self.scale_y:.2f}")

    def load_game_assets(self):
        """Load all game assets"""
        # Load map data
        self.map_data = self.load_tmx_map_with_tilesets('maps/usethis.tmx')
        self.collision_grid = self.create_collision_grid()
        
        # Initialize game objects
        self.player = None  # Will be initialized in reset_game
        self.parent_npc = None
        self.doctor_npc = None
        self.coins = []
        self.traps = []
        
        print("Game assets loaded successfully!")

    def load_sound_effects(self):
        """Load sound effects for the game"""
        self.sounds = {}
        
        # Sound effect paths (if they exist)
        sound_paths = {
            'walk': 'sfx/walk.mp3',
            'jump': 'sfx/jump.mp3',
            'coin': 'sfx/coin.mp3',
            'die': 'sfx/die.mp3',
            'damage': 'sfx/damage.mp3',
            'background': 'sfx/background.mp3'
        }
        
        # Load sound effects
        for sound_name, sound_path in sound_paths.items():
            try:
                if os.path.exists(sound_path):
                    self.sounds[sound_name] = pygame.mixer.Sound(sound_path)
                    print(f"Loaded sound: {sound_name}")
                else:
                    print(f"Sound file not found: {sound_path}")
            except Exception as e:
                print(f"Error loading sound {sound_name}: {e}")
        
        # Start background music
        try:
            if 'background' in self.sounds:
                self.sounds['background'].play(-1)  # Loop background music
                print("Background music started")
        except Exception as e:
            print(f"Error playing background music: {e}")

    def load_tmx_map_with_tilesets(self, tmx_file):
        """Load TMX map with proper tileset handling"""
        tree = ET.parse(tmx_file)
        root = tree.getroot()
        
        # Get map properties
        map_width = int(root.get('width'))
        map_height = int(root.get('height'))
        tile_width = int(root.get('tilewidth'))
        tile_height = int(root.get('tileheight'))
        
        # Load tilesets
        self.tilesets = {}
        for tileset in root.findall('tileset'):
            firstgid = int(tileset.get('firstgid'))
            source = tileset.get('source')
            
            # Load tileset image
            if source:
                # Handle relative paths
                tileset_path = f"maps/{source}"
                tileset_data = ET.parse(tileset_path)
                tileset_root = tileset_data.getroot()
                
                # Get image source
                image_element = tileset_root.find('image')
                if image_element is not None:
                    image_source = image_element.get('source')
                    image_width = int(image_element.get('width'))
                    image_height = int(image_element.get('height'))
                    
                    # Load the tileset image
                    tileset_image_path = f"maps/{image_source}"
                    if os.path.exists(tileset_image_path):
                        tileset_surface = pygame.image.load(tileset_image_path).convert_alpha()
                        self.tilesets[firstgid] = {
                            'image': tileset_surface,
                            'tilewidth': tile_width,
                            'tileheight': tile_height,
                            'columns': tileset_surface.get_width() // tile_width,
                            'name': source,
                            'firstgid': firstgid
                        }
                        print(f"Loaded tileset: {source} (GID {firstgid}) - Image size: {tileset_surface.get_width()}x{tileset_surface.get_height()}")
                    else:
                        print(f"Warning: Tileset image not found: {tileset_image_path}")
        
        # Load layers
        layers = []
        for layer in root.findall('layer'):
            layer_data = {
                'name': layer.get('name'),
                'width': int(layer.get('width')),
                'height': int(layer.get('height')),
                'data': []
            }
            
            data_elem = layer.find('data')
            if data_elem is not None:
                csv_data = data_elem.text.strip()
                layer_data['data'] = [int(x) for x in csv_data.split(',') if x.strip()]
            
            layers.append(layer_data)
        
        # Load object groups
        object_groups = {}
        for objectgroup in root.findall('objectgroup'):
            group_name = objectgroup.get('name')
            objects = []
            
            for obj in objectgroup.findall('object'):
                obj_data = {
                    'id': int(obj.get('id')),
                    'x': float(obj.get('x')),
                    'y': float(obj.get('y')),
                    'width': float(obj.get('width', 0)),
                    'height': float(obj.get('height', 0))
                }
                objects.append(obj_data)
            
            object_groups[group_name] = objects
        
        return {
            'width': map_width,
            'height': map_height,
            'tilewidth': tile_width,
            'tileheight': tile_height,
            'layers': layers,
            'object_groups': object_groups
        }

    def get_tileset_for_gid(self, gid):
        """Get the appropriate tileset for a given GID"""
        if gid == 0:
            return None
            
        # Find the tileset with the highest firstgid that's <= gid
        best_tileset = None
        best_firstgid = 0
        
        for firstgid, tileset in self.tilesets.items():
            if firstgid <= gid and firstgid > best_firstgid:
                best_tileset = tileset
                best_firstgid = firstgid
        
        return best_tileset

    def get_player_spawn_point(self):
        """Get the player spawn point from the TMX object group"""
        if 'object_groups' in self.map_data and 'player' in self.map_data['object_groups']:
            player_objects = self.map_data['object_groups']['player']
            if player_objects:
                spawn = player_objects[0]
                x = spawn['x']
                y = spawn['y']
                print(f"Player spawn point from TMX: {x}, {y}")
                return x, y
        
        # Fallback to default spawn point
        print("Using fallback spawn point")
        return 100, 500

    def create_collision_grid(self):
        """Create collision grid from ground layer"""
        grid = [[0 for _ in range(self.map_data['width'])] for _ in range(self.map_data['height'])]
        
        # Get ground layer
        ground_layer = next((l for l in self.map_data['layers'] if l['name'] == 'ground'), None)
        
        if ground_layer:
            solid_tiles = 0
            print(f"Ground layer found: {ground_layer['name']}")
            print(f"Ground layer dimensions: {ground_layer['width']}x{ground_layer['height']}")
            print(f"Ground layer data length: {len(ground_layer['data'])}")
            
            for y in range(self.map_data['height']):
                for x in range(self.map_data['width']):
                    index = y * ground_layer['width'] + x
                    if index < len(ground_layer['data']):
                        gid = ground_layer['data'][index]
                        if gid != 0:
                            grid[y][x] = 1  # Solid tile
                            solid_tiles += 1
            
            print(f"Created collision grid with {solid_tiles} solid tiles")
            print(f"Grid dimensions: {len(grid)}x{len(grid[0])}")
        else:
            print("No ground layer found for collision grid")
            print("Available layers:")
            for layer in self.map_data['layers']:
                print(f"  - {layer['name']}")
        
        return grid

    def reset_game(self):
        """Reset game state"""
        # Initialize game state
        self.lives = 3
        self.coins_collected = 0
        self.coins_needed = 10
        self.game_state = "playing"
        self.doctor_spawned = False
        
        # Get player spawn point from TMX
        spawn_point = self.get_player_spawn_point()
        
        # Initialize player
        if spawn_point:
            print(f"Player spawn point: {spawn_point[0]:.1f}, {spawn_point[1]:.1f}")
            self.player = Player(spawn_point[0], spawn_point[1], self)
        else:
            # Default spawn position
            default_x = 100
            default_y = 500
            print(f"Default player spawn: {default_x:.1f}, {default_y:.1f}")
            self.player = Player(default_x, default_y, self)
        
        # Pass sounds to player after loading
        if hasattr(self, 'sounds'):
            self.player.game_sounds = self.sounds
        
        # Initialize NPCs
        self.parent_npc = ParentNPC(200, 400, self.scale_factor)
        self.doctor_npc = None  # Will be spawned when needed
        
        # Initialize coins
        self.coins = []
        for coin_data in self.map_data['object_groups'].get('coin', []):
            coin_x = coin_data['x'] * self.scale_x
            coin_y = coin_data['y'] * self.scale_y
            self.coins.append(Coin(coin_x, coin_y))
        
        # Initialize traps
        self.traps = []
        if 'trap' in self.map_data['object_groups']:
            for trap_data in self.map_data['object_groups']['trap']:
                trap_x = trap_data['x'] * self.scale_x
                trap_y = trap_data['y'] * self.scale_y
                self.traps.append(Trap(trap_x, trap_y))
        
        # Initialize UI
        self.ui = UI(self.screen)
        
        # Initialize camera
        self.camera_x = 0
        self.camera_y = 0
        self.update_camera()

    def update_camera(self):
        """Update camera to follow player and clamp to map boundaries"""
        # Map dimensions in pixels
        map_width = self.map_data['width'] * self.map_data['tilewidth']
        map_height = self.map_data['height'] * self.map_data['tileheight']
        
        # Center camera on player
        target_camera_x = self.player.x - self.screen_width // 2
        target_camera_y = self.player.y - self.screen_height // 2
        
        # Clamp camera to map boundaries
        max_camera_x = max(0, map_width - self.screen_width)
        max_camera_y = max(0, map_height - self.screen_height)
        
        self.camera_x = max(0, min(target_camera_x, max_camera_x))
        self.camera_y = max(0, min(target_camera_y, max_camera_y))

    def render_map(self):
        """Render the TMX map with all layers"""
        # Get all layers and sort them by name for proper rendering order
        all_layers = self.map_data['layers']
        
        # Sort layers: background first, then ground
        layers_sorted = sorted(all_layers, key=lambda x: x['name'])
        
        # Calculate tile dimensions
        tile_width = self.map_data['tilewidth']
        tile_height = self.map_data['tileheight']
        
        # Render all layers
        for layer in layers_sorted:
            tiles_rendered = 0
            for y in range(self.map_data['height']):
                for x in range(self.map_data['width']):
                    index = y * layer['width'] + x
                    if index < len(layer['data']):
                        gid = layer['data'][index]
                        if gid != 0:
                            tileset = self.get_tileset_for_gid(gid)
                            if tileset:
                                # Calculate tile position
                                local_tid = gid - tileset.get('firstgid', 0)
                                if local_tid >= 0:  # Ensure valid local tile ID
                                    tile_x = (local_tid % tileset['columns']) * tileset['tilewidth']
                                    tile_y = (local_tid // tileset['columns']) * tileset['tileheight']
                                    
                                    screen_x = x * tile_width - self.camera_x
                                    screen_y = y * tile_height - self.camera_y

                                    # Only render tiles that are visible on screen
                                    if -tile_width <= screen_x < self.screen.get_width() and -tile_height <= screen_y < self.screen.get_height():
                                        # Use tile cache for performance
                                        cache_key = f"{tileset['name']}_{local_tid}"
                                        
                                        if cache_key not in self.tile_cache:
                                            try:
                                                tile_surface = pygame.Surface((tile_width, tile_height), pygame.SRCALPHA)
                                                tile_surface.blit(tileset['image'], (0, 0),
                                                                  (tile_x, tile_y, tile_width, tile_height))
                                                self.tile_cache[cache_key] = tile_surface
                                            except Exception as e:
                                                continue
                                        else:
                                            tile_surface = self.tile_cache[cache_key]
                                        
                                        self.screen.blit(tile_surface, (screen_x, screen_y))
                                        tiles_rendered += 1

    def update_performance_monitoring(self):
        """Update performance monitoring"""
        current_time = time.time()
        frame_time = current_time - self.last_frame_time
        self.frame_times.append(frame_time)
        
        # Keep only last 60 frames
        if len(self.frame_times) > 60:
            self.frame_times.pop(0)
        
        self.last_frame_time = current_time
        
        # Calculate average FPS
        if len(self.frame_times) > 0:
            avg_frame_time = sum(self.frame_times) / len(self.frame_times)
            fps = 1.0 / avg_frame_time if avg_frame_time > 0 else 0
            self.fps = fps

    def handle_events(self):
        """Handle pygame events"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_r:
                    self.reset_game()
                elif event.key == pygame.K_SPACE and not self.paused:
                    # Jump handled in player update
                    pass

    def update_game(self, dt):
        """Update game logic"""
        if self.game_state != "playing":
            return
            
        # Update player with input
        keys = pygame.key.get_pressed()
        self.player.update(keys, dt)
        
        # Update camera to follow player
        self.update_camera()
        
        # Check player collision with ground
        self.check_player_ground_collision()
        
        # Check collisions with traps
        self.check_trap_collisions()
        
        # Check coin collections
        self.check_coin_collisions()
        
        # Check if doctor should spawn
        if not self.doctor_spawned and self.coins_collected >= self.coins_needed:
            self.spawn_doctor()
        
        # Check victory condition
        if self.doctor_npc and self.player.rect.colliderect(self.doctor_npc.rect):
            self.game_state = "victory"
        
        # Update performance monitoring
        self.update_performance_monitoring()

    def check_player_ground_collision(self):
        """Check if player collides with solid ground tiles"""
        if "ground" not in [layer['name'] for layer in self.map_data['layers']]:
            return
            
        ground_layer = next((l for l in self.map_data['layers'] if l['name'] == 'ground'), None)
        if not ground_layer:
            return
        
        # Check collision with tiles
        left_tile = self.player.rect.left // self.map_data['tilewidth']
        right_tile = self.player.rect.right // self.map_data['tilewidth']
        top_tile = self.player.rect.top // self.map_data['tileheight']
        bottom_tile = self.player.rect.bottom // self.map_data['tileheight']
        
        # Make sure we're within map bounds
        if (left_tile < 0 or right_tile >= self.map_data['width'] or 
            top_tile < 0 or bottom_tile >= self.map_data['height']):
            return
        
        # Check each tile the player overlaps
        for x in range(left_tile, right_tile + 1):
            for y in range(top_tile, bottom_tile + 1):
                if x < self.map_data['width'] and y < self.map_data['height']:
                    index = y * ground_layer['width'] + x
                    if index < len(ground_layer['data']):
                        tile_gid = ground_layer['data'][index]
                        if tile_gid != 0:  # If there's a solid tile
                            # Handle collision
                            if self.player.velocity_y > 0:  # Falling
                                self.player.rect.y = y * self.map_data['tileheight'] - self.player.rect.height
                                self.player.on_ground = True
                                self.player.velocity_y = 0
                            elif self.player.velocity_y < 0:  # Jumping
                                self.player.rect.y = (y + 1) * self.map_data['tileheight']
                                self.player.velocity_y = 0
                            elif self.player.velocity_x > 0:  # Moving right
                                self.player.rect.x = x * self.map_data['tilewidth'] - self.player.rect.width
                            elif self.player.velocity_x < 0:  # Moving left
                                self.player.rect.x = (x + 1) * self.map_data['tilewidth']
                            return

    def check_trap_collisions(self):
        """Check if player collides with any trap"""
        for trap in self.traps:
            if self.player.rect.colliderect(trap.rect):
                self.player_die()
                break

    def check_coin_collisions(self):
        """Check if player collects any coins"""
        coins_to_remove = []
        for coin in self.coins:
            if self.player.rect.colliderect(coin.rect):
                coins_to_remove.append(coin)
                self.coins_collected += 1
                print(f"Coin collected! {self.coins_collected}/{self.coins_needed}")
        
        # Remove collected coins
        for coin in coins_to_remove:
            self.coins.remove(coin)

    def spawn_doctor(self):
        """Spawn the doctor NPC when enough coins are collected"""
        if not self.doctor_spawned:
            self.doctor_npc = DoctorNPC(1500, 400, self.scale_factor)
            self.doctor_spawned = True
            print("Doctor NPC spawned!")

    def player_die(self):
        """Handle player death"""
        self.lives -= 1
        if self.lives <= 0:
            self.game_state = "game_over"
        else:
            # Reset player position
            spawn_point = self.get_player_spawn_point()
            if spawn_point:
                self.player.rect.x = spawn_point[0]
                self.player.rect.y = spawn_point[1]
            else:
                self.player.rect.x = 100
                self.player.rect.y = 500
            self.player.velocity_x = 0
            self.player.velocity_y = 0

    def render(self):
        """Main rendering function"""
        # Clear screen
        self.screen.fill((135, 206, 235))  # Sky blue background
        
        # Render all map layers properly
        self.render_map()
        
        # Render game objects
        self.player.draw(self.screen, self.camera_x, self.camera_y)
        
        # Render NPCs
        if self.parent_npc:
            self.parent_npc.draw(self.screen, self.camera_x, self.camera_y)
        
        if self.doctor_npc:
            self.doctor_npc.draw(self.screen, self.camera_x, self.camera_y)
        
        # Render coins
        for coin in self.coins:
            coin.draw(self.screen, self.camera_x, self.camera_y)
        
        # Render traps
        for trap in self.traps:
            trap.draw(self.screen, self.camera_x, self.camera_y)
        
        # Draw UI
        self.ui.draw(self.lives, self.coins_collected, self.coins_needed, self.game_state)
        
        # Update display
        pygame.display.flip()

    def run(self):
        """Main game loop"""
        self.running = True
        dt = 0.016  # Initialize dt with a default value
        
        while self.running:
            # Handle events
            self.handle_events()
            
            if not self.paused:
                self.update_game(dt)
                self.render()
            
            # Cap at 60 FPS for better performance
            dt = self.clock.tick(60) / 1000.0
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
