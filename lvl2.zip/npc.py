"""
NPC class for the 2D platformer game.
Contains ParentNPC and DoctorNPC classes for quest interactions.
"""

import pygame
import math

class ParentNPC:
    def __init__(self, x, y, scale_factor=1.0):
        """Initialize the parent NPC at the specified position."""
        self.x = x
        self.y = y
        self.width = int(32 * scale_factor)  # Normal base width
        self.height = int(48 * scale_factor)  # Normal base height
        self.rect = pygame.Rect(x, y, self.width, self.height)
        
        # Animation properties
        self.animation_timer = 0
        self.bob_offset = 0
        self.bob_speed = 0.05
        self.bob_amplitude = 2
        
        # Dialog properties
        self.show_dialog = True
        self.dialog_timer = 0
        self.dialog_duration = 300  # frames (5 seconds at 60 FPS)
        
        # Quest properties
        self.quest_given = False
        self.quest_text = "Find the doctor and save him!"
        
        # Load NPC sprite
        self.sprite = self.load_sprite()
    
    def load_sprite(self):
        """Load NPC sprite image."""
        try:
            sprite = pygame.image.load("images/npc/Walk1.png").convert_alpha()
            # Scale the sprite to match NPC size
            sprite = pygame.transform.scale(sprite, (self.width, self.height))
            return sprite
        except pygame.error as e:
            print(f"Error loading NPC sprite: {e}")
            # Fallback to colored rectangle
            sprite = pygame.Surface((self.width, self.height))
            sprite.fill((100, 200, 100))  # Green for parent NPC
            return sprite
    
    def update(self):
        """Update NPC animation and dialog state."""
        # Bobbing animation
        self.animation_timer += 1
        self.bob_offset = math.sin(self.animation_timer * self.bob_speed) * self.bob_amplitude
        self.rect.y = self.y + self.bob_offset
        
        # Dialog timer
        if self.show_dialog:
            self.dialog_timer += 1
            if self.dialog_timer >= self.dialog_duration:
                self.show_dialog = False
    
    def interact(self):
        """Handle interaction with the player."""
        if not self.quest_given:
            self.quest_given = True
            self.show_dialog = True
            self.dialog_timer = 0
            return self.quest_text
        return None
    
    def draw(self, screen, camera_x, camera_y):
        """Draw the parent NPC on the screen."""
        # Calculate screen position with camera offset
        screen_x = self.rect.x - camera_x
        screen_y = self.rect.y - camera_y
        
        # Draw NPC sprite
        screen.blit(self.sprite, (screen_x, screen_y))
        
        # Draw dialog bubble if showing dialog
        if self.show_dialog:
            self.draw_dialog(screen)
    
    def draw_dialog(self, screen):
        """Draw the dialog bubble above the NPC."""
        # Dialog bubble dimensions
        bubble_width = 200
        bubble_height = 60
        bubble_x = self.rect.centerx - bubble_width // 2
        bubble_y = self.rect.y - bubble_height - 10
        
        # Draw bubble background
        bubble_rect = pygame.Rect(bubble_x, bubble_y, bubble_width, bubble_height)
        pygame.draw.rect(screen, (255, 255, 255), bubble_rect)
        pygame.draw.rect(screen, (0, 0, 0), bubble_rect, 2)
        
        # Draw bubble tail
        tail_points = [
            (self.rect.centerx - 5, bubble_y + bubble_height),
            (self.rect.centerx + 5, bubble_y + bubble_height),
            (self.rect.centerx, bubble_y + bubble_height + 10)
        ]
        pygame.draw.polygon(screen, (255, 255, 255), tail_points)
        pygame.draw.polygon(screen, (0, 0, 0), tail_points, 2)
        
        # Draw text
        font = pygame.font.Font(None, 24)
        text_surface = font.render(self.quest_text, True, (0, 0, 0))
        text_rect = text_surface.get_rect(center=(bubble_x + bubble_width // 2, 
                                                bubble_y + bubble_height // 2))
        screen.blit(text_surface, text_rect)

class DoctorNPC:
    def __init__(self, x, y, scale_factor=1.0):
        """Initialize the doctor NPC at the specified position."""
        self.x = x
        self.y = y
        self.width = int(32 * scale_factor)  # Normal base width
        self.height = int(48 * scale_factor)  # Normal base height
        self.rect = pygame.Rect(x, y, self.width, self.height)
        
        # Animation properties
        self.animation_timer = 0
        self.bob_offset = 0
        self.bob_speed = 0.05
        self.bob_amplitude = 2
        
        # Dialog properties
        self.show_dialog = True
        self.dialog_timer = 0
        self.dialog_duration = 300  # frames (5 seconds at 60 FPS)
        
        # Quest properties
        self.rescued = False
        self.rescue_text = "Thank you for saving me!"
        
        # Load NPC sprite
        self.sprite = self.load_sprite()
    
    def load_sprite(self):
        """Load NPC sprite image."""
        try:
            sprite = pygame.image.load("images/npc/Walk1.png").convert_alpha()
            # Scale the sprite to match NPC size
            sprite = pygame.transform.scale(sprite, (self.width, self.height))
            return sprite
        except pygame.error as e:
            print(f"Error loading NPC sprite: {e}")
            # Fallback to colored rectangle
            sprite = pygame.Surface((self.width, self.height))
            sprite.fill((200, 200, 200))  # Light gray for doctor NPC
            return sprite
    
    def update(self):
        """Update NPC animation and dialog state."""
        # Bobbing animation
        self.animation_timer += 1
        self.bob_offset = math.sin(self.animation_timer * self.bob_speed) * self.bob_amplitude
        self.rect.y = self.y + self.bob_offset
        
        # Dialog timer
        if self.show_dialog:
            self.dialog_timer += 1
            if self.dialog_timer >= self.dialog_duration:
                self.show_dialog = False
    
    def interact(self):
        """Handle interaction with the player."""
        if not self.rescued:
            self.rescued = True
            self.show_dialog = True
            self.dialog_timer = 0
            return self.rescue_text
        return None
    
    def draw(self, screen, camera_x, camera_y):
        """Draw the doctor NPC on the screen."""
        # Calculate screen position with camera offset
        screen_x = self.rect.x - camera_x
        screen_y = self.rect.y - camera_y
        
        # Draw NPC sprite
        screen.blit(self.sprite, (screen_x, screen_y))
        
        # Draw dialog bubble if showing dialog
        if self.show_dialog:
            self.draw_dialog(screen)
    
    def draw_dialog(self, screen):
        """Draw the dialog bubble above the NPC."""
        # Dialog bubble dimensions
        bubble_width = 200
        bubble_height = 60
        bubble_x = self.rect.centerx - bubble_width // 2
        bubble_y = self.rect.y - bubble_height - 10
        
        # Draw bubble background
        bubble_rect = pygame.Rect(bubble_x, bubble_y, bubble_width, bubble_height)
        pygame.draw.rect(screen, (255, 255, 255), bubble_rect)
        pygame.draw.rect(screen, (0, 0, 0), bubble_rect, 2)
        
        # Draw bubble tail
        tail_points = [
            (self.rect.centerx - 5, bubble_y + bubble_height),
            (self.rect.centerx + 5, bubble_y + bubble_height),
            (self.rect.centerx, bubble_y + bubble_height + 10)
        ]
        pygame.draw.polygon(screen, (255, 255, 255), tail_points)
        pygame.draw.polygon(screen, (0, 0, 0), tail_points, 2)
        
        # Draw text
        font = pygame.font.Font(None, 24)
        text_surface = font.render(self.rescue_text, True, (0, 0, 0))
        text_rect = text_surface.get_rect(center=(bubble_x + bubble_width // 2, 
                                                bubble_y + bubble_height // 2))
        screen.blit(text_surface, text_rect)
