"""
Player class for the 2D platformer game.
Handles player movement, animation, and collision detection.
"""

import pygame
import math

class Player:
    def __init__(self, x, y, game, scale=1.0):
        """Initialize the player with position and game reference for collision detection."""
        self.game = game
        self.TILE_SIZE = 32
        self.scale = scale
        
        # Player dimensions (scaled) - normal size for full-size map
        self.width = int(24 * scale)  # Normal base width
        self.height = int(32 * scale)  # Normal base height
        
        # Create player rectangle
        self.rect = pygame.Rect(x, y, self.width, self.height)
        
        # Movement properties (scaled)
        self.velocity_x = 0
        self.velocity_y = 0
        self.speed = 5 * scale
        self.jump_power = -20 * scale  # 20% more jump power (-12 * 1.2 = -14.4)
        self.gravity = 0.8 * scale
        self.max_fall_speed = 15 * scale
        
        # Player state
        self.on_ground = False
        self.facing_right = True
        
        # Animation properties
        self.animation_timer = 0
        self.animation_speed = 0.2
        self.current_frame = 0
        
        # Load player sprites (using simple colored rectangles for now)
        self.load_sprites()
        
        # Input handling
        self.keys_pressed = {
            'left': False,
            'right': False,
            'jump': False
        }
    
    def load_sprites(self):
        """Load player sprite images from the images folder."""
        self.sprites = {
            'idle': [],
            'walk': [],
            'jump': []
        }
        
        try:
            # Load idle sprite (front facing)
            idle_sprite = pygame.image.load("images/front facing.png").convert_alpha()
            self.sprites['idle'].append(idle_sprite)
            
            # Load jump sprite
            jump_sprite = pygame.image.load("images/jump.png").convert_alpha()
            self.sprites['jump'].append(jump_sprite)
            
            # Load walk sprites (using left.png for now, we can add more later)
            walk_sprite = pygame.image.load("images/left.png").convert_alpha()
            # Create multiple frames for walking animation
            for i in range(4):
                self.sprites['walk'].append(walk_sprite)
            
            print("Character sprites loaded successfully!")
            
        except pygame.error as e:
            print(f"Error loading character sprites: {e}")
            print("Falling back to colored rectangles...")
            
            # Fallback to colored rectangles if images can't be loaded
            self.sprites = {
                'idle': [pygame.Surface((self.width, self.height))],
                'walk': [pygame.Surface((self.width, self.height)) for _ in range(4)],
                'jump': [pygame.Surface((self.width, self.height))]
            }
            
            # Color the sprites
            for sprite in self.sprites['idle']:
                sprite.fill((0, 100, 200))  # Blue for idle
            
            for i, sprite in enumerate(self.sprites['walk']):
                color_intensity = 150 + (i * 20)
                sprite.fill((0, color_intensity, 200))
            
            for sprite in self.sprites['jump']:
                sprite.fill((200, 100, 0))  # Orange for jumping
    
    def handle_input(self, keys):
        """Handle keyboard input for player movement."""
        # Horizontal movement
        self.keys_pressed['left'] = keys[pygame.K_LEFT] or keys[pygame.K_a]
        self.keys_pressed['right'] = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        
        # Jumping
        self.keys_pressed['jump'] = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]
    
    def update(self, keys, dt):
        """Update player position and state."""
        self.handle_input(keys)
        
        # Reset horizontal velocity
        self.velocity_x = 0
        
        # Handle horizontal movement
        if self.keys_pressed['left']:
            self.velocity_x = -self.speed
            self.facing_right = False
        elif self.keys_pressed['right']:
            self.velocity_x = self.speed
            self.facing_right = True
        
        # Handle jumping
        if self.keys_pressed['jump'] and self.on_ground:
            self.velocity_y = self.jump_power
            self.on_ground = False
        
        # Apply gravity
        self.velocity_y += self.gravity * dt * 60  # Scale by dt and 60 for consistent gravity
        if self.velocity_y > self.max_fall_speed:
            self.velocity_y = self.max_fall_speed
        
        # Move player
        self.move()
        
        # Update animation
        self.update_animation()
    
    def move(self):
        """Move the player. Collision detection is handled by the main game."""
        # Move horizontally
        self.rect.x += self.velocity_x
        
        # Move vertically
        self.rect.y += self.velocity_y
    
    def check_collision(self):
        """Check if the player collides with solid tiles."""
        # This will be handled by the main game class
        # For now, return False to allow movement
        return False
    
    def update_animation(self):
        """Update player animation based on current state."""
        self.animation_timer += 1
        
        if not self.on_ground:
            # Jumping animation
            self.current_sprite = self.sprites['jump'][0]
        elif self.velocity_x != 0:
            # Walking animation
            if self.animation_timer >= self.animation_speed * 60:  # 60 FPS
                self.current_frame = (self.current_frame + 1) % len(self.sprites['walk'])
                self.animation_timer = 0
            self.current_sprite = self.sprites['walk'][self.current_frame]
        else:
            # Idle animation
            self.current_sprite = self.sprites['idle'][0]
    
    def draw(self, screen, camera_x, camera_y):
        """Draw the player on the screen."""
        # Calculate screen position with camera offset
        screen_x = self.rect.x - camera_x
        screen_y = self.rect.y - camera_y
        
        # Debug output
        print(f"Drawing player at screen position: ({screen_x}, {screen_y})")
        print(f"Player rect: {self.rect}")
        print(f"Camera: ({camera_x}, {camera_y})")
        
        # Flip sprite if facing left
        sprite_to_draw = self.current_sprite
        if not self.facing_right:
            sprite_to_draw = pygame.transform.flip(self.current_sprite, True, False)
        
        # Scale the sprite
        if self.scale != 1.0:
            sprite_width = int(sprite_to_draw.get_width() * self.scale)
            sprite_height = int(sprite_to_draw.get_height() * self.scale)
            sprite_to_draw = pygame.transform.scale(sprite_to_draw, (sprite_width, sprite_height))
        
        screen.blit(sprite_to_draw, (screen_x, screen_y))
        
        # Draw a simple rectangle as backup to make sure player is visible
        pygame.draw.rect(screen, (255, 0, 0), (screen_x, screen_y, self.rect.width, self.rect.height), 2)
