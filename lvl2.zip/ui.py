"""
UI class for the 2D platformer game.
Handles all user interface elements including HUD, game over screen, and victory screen.
"""

import pygame

class UI:
    def __init__(self, screen):
        """Initialize the UI with the game screen."""
        self.screen = screen
        self.font_large = pygame.font.Font(None, 48)
        self.font_medium = pygame.font.Font(None, 36)
        self.font_small = pygame.font.Font(None, 24)
        
        # Colors
        self.white = (255, 255, 255)
        self.black = (0, 0, 0)
        self.red = (255, 0, 0)
        self.green = (0, 255, 0)
        self.blue = (0, 0, 255)
        self.yellow = (255, 255, 0)
        self.gray = (128, 128, 128)
        
        # UI element positions
        self.hud_padding = 20
        self.hud_height = 60
    
    def draw_hud(self, lives, coins_collected, coins_needed):
        """Draw the heads-up display with lives and coin count."""
        # Draw HUD background
        hud_rect = pygame.Rect(0, 0, self.screen.get_width(), self.hud_height)
        pygame.draw.rect(self.screen, (0, 0, 0, 128), hud_rect)  # Semi-transparent black
        pygame.draw.rect(self.screen, self.white, hud_rect, 2)
        
        # Draw lives
        lives_text = f"Lives: {lives}"
        lives_surface = self.font_medium.render(lives_text, True, self.white)
        self.screen.blit(lives_surface, (self.hud_padding, 15))
        
        # Draw hearts for lives
        heart_x = self.hud_padding + 120
        for i in range(lives):
            heart_rect = pygame.Rect(heart_x + i * 25, 15, 20, 20)
            self.draw_heart(heart_rect)
        
        # Draw coin count
        coin_text = f"Coins: {coins_collected}/{coins_needed}"
        coin_surface = self.font_medium.render(coin_text, True, self.yellow)
        coin_x = self.screen.get_width() - coin_surface.get_width() - self.hud_padding
        self.screen.blit(coin_surface, (coin_x, 15))
        
        # Draw coin icon
        coin_icon_rect = pygame.Rect(coin_x - 30, 15, 20, 20)
        self.draw_coin_icon(coin_icon_rect)
        
        # Draw quest status
        if coins_collected < coins_needed:
            quest_text = f"Collect {coins_needed - coins_collected} more coins to find the doctor!"
            quest_surface = self.font_small.render(quest_text, True, self.white)
            quest_x = (self.screen.get_width() - quest_surface.get_width()) // 2
            self.screen.blit(quest_surface, (quest_x, 40))
        else:
            quest_text = "Find the doctor and save him!"
            quest_surface = self.font_small.render(quest_text, True, self.green)
            quest_x = (self.screen.get_width() - quest_surface.get_width()) // 2
            self.screen.blit(quest_surface, (quest_x, 40))
    
    def draw_heart(self, rect):
        """Draw a heart icon for lives."""
        # Simple heart shape using circles and triangle
        center_x = rect.centerx
        center_y = rect.centery
        
        # Left circle
        pygame.draw.circle(self.screen, self.red, 
                         (center_x - 3, center_y - 2), 4)
        # Right circle
        pygame.draw.circle(self.screen, self.red, 
                         (center_x + 3, center_y - 2), 4)
        # Triangle (pointing down)
        heart_points = [
            (center_x - 6, center_y + 1),
            (center_x + 6, center_y + 1),
            (center_x, center_y + 6)
        ]
        pygame.draw.polygon(self.screen, self.red, heart_points)
    
    def draw_coin_icon(self, rect):
        """Draw a coin icon."""
        center_x = rect.centerx
        center_y = rect.centery
        radius = rect.width // 2
        
        # Outer ring
        pygame.draw.circle(self.screen, (255, 215, 0), (center_x, center_y), radius)
        pygame.draw.circle(self.screen, (255, 255, 0), (center_x, center_y), radius - 2)
        
        # Inner circle
        pygame.draw.circle(self.screen, (255, 215, 0), (center_x, center_y), radius - 4)
        
        # Highlight
        pygame.draw.circle(self.screen, (255, 255, 255), 
                         (center_x - 2, center_y - 2), 2)
    
    def draw_game_over_screen(self):
        """Draw the game over screen."""
        # Semi-transparent overlay
        overlay = pygame.Surface(self.screen.get_size())
        overlay.set_alpha(128)
        overlay.fill(self.black)
        self.screen.blit(overlay, (0, 0))
        
        # Game Over text
        game_over_text = "GAME OVER"
        game_over_surface = self.font_large.render(game_over_text, True, self.red)
        game_over_rect = game_over_surface.get_rect(center=(self.screen.get_width() // 2, 
                                                          self.screen.get_height() // 2 - 50))
        self.screen.blit(game_over_surface, game_over_rect)
        
        # Restart instruction
        restart_text = "Press R to restart or ESC to quit"
        restart_surface = self.font_medium.render(restart_text, True, self.white)
        restart_rect = restart_surface.get_rect(center=(self.screen.get_width() // 2, 
                                                      self.screen.get_height() // 2 + 20))
        self.screen.blit(restart_surface, restart_rect)
    
    def draw_victory_screen(self):
        """Draw the victory screen."""
        # Semi-transparent overlay
        overlay = pygame.Surface(self.screen.get_size())
        overlay.set_alpha(128)
        overlay.fill(self.black)
        self.screen.blit(overlay, (0, 0))
        
        # Victory text
        victory_text = "VICTORY!"
        victory_surface = self.font_large.render(victory_text, True, self.green)
        victory_rect = victory_surface.get_rect(center=(self.screen.get_width() // 2, 
                                                      self.screen.get_height() // 2 - 50))
        self.screen.blit(victory_surface, victory_rect)
        
        # Success message
        success_text = "You found and saved the doctor!"
        success_surface = self.font_medium.render(success_text, True, self.white)
        success_rect = success_surface.get_rect(center=(self.screen.get_width() // 2, 
                                                      self.screen.get_height() // 2 + 20))
        self.screen.blit(success_surface, success_rect)
        
        # Restart instruction
        restart_text = "Press R to play again or ESC to quit"
        restart_surface = self.font_medium.render(restart_text, True, self.white)
        restart_rect = restart_surface.get_rect(center=(self.screen.get_width() // 2, 
                                                      self.screen.get_height() // 2 + 60))
        self.screen.blit(restart_surface, restart_rect)
    
    def draw_controls(self):
        """Draw control instructions."""
        controls_text = [
            "Controls:",
            "Arrow Keys or WASD - Move",
            "Space or Up/W - Jump",
            "ESC - Quit"
        ]
        
        start_y = self.screen.get_height() - 120
        for i, text in enumerate(controls_text):
            color = self.white if i == 0 else self.gray
            surface = self.font_small.render(text, True, color)
            self.screen.blit(surface, (self.hud_padding, start_y + i * 20))
    
    def draw(self, lives, coins_collected, coins_needed, game_state):
        """Main draw method that calls appropriate UI elements."""
        # Always draw HUD
        self.draw_hud(lives, coins_collected, coins_needed)
        
        # Draw game state specific screens
        if game_state == "game_over":
            self.draw_game_over_screen()
        elif game_state == "victory":
            self.draw_victory_screen()
        
        # Draw controls (only during gameplay)
        if game_state == "playing":
            self.draw_controls()
