FONT: Riffic

http://www.dafont.com/search.php?q=riffic